import UniformTypeIdentifiers
import SwiftUI
struct AdminContentView: View {
    @StateObject private var api=AdminAPI(); @State private var featureName=""; @State private var featureSlug=""; @State private var featureDesc=""; @State private var keyLabel=""; @State private var days="30"; @State private var showingKey=false; @State private var fileTarget: AdminFeature?; @State private var importing=false
    var body: some View { NavigationStack { List { Section("Nova função") { TextField("Identificador (ex.: wallhack)",text:$featureSlug); TextField("Nome",text:$featureName); TextField("Descrição",text:$featureDesc); Button("Criar função") { Task { await api.createFeature(slug:featureSlug,name:featureName,description:featureDesc); featureSlug=""; featureName=""; featureDesc="" } } }
        Section("Funções e patches") { ForEach(api.features) { f in Toggle(isOn:Binding(get:{f.enabled},set:{v in Task{await api.toggle(f,enabled:v)}})){ VStack(alignment:.leading){Text(f.name); Text(f.description ?? f.slug).font(.caption).foregroundStyle(.secondary)}             Button("Importar pacote .3105") { importing=true }
        }
        Section("Criar KEY single-device") { TextField("Nome personalizado",text:$keyLabel); TextField("Validade em dias",text:$days).keyboardType(.numberPad); Button("Gerar KEY") { Task { await api.createKey(label:keyLabel,days:Int(days) ?? 30); showingKey=true } }; if let key=api.generatedKey { Text("KEY gerada: \(key)").textSelection(.enabled).foregroundStyle(.green) } }
        Section("KEYs e clientes") { ForEach(api.keys) { k in VStack(alignment:.leading){ Text(k.label).bold(); Text("\(k.status) • expira: \(k.expiresAt ?? "-")").font(.caption); Text("cliente: \(k.client?.name ?? "livre")").font(.caption); HStack{ Button("Excluir",role:.destructive){Task{await api.deleteKey(k)}}; Button("Permissões"){Task{await api.setKeyFeatures(k,featureIds:api.features.filter{$0.enabled}.map{$0.id})}} } } } }
        Section { Text(api.message).font(.footnote); Button("Atualizar agora"){Task{await api.refresh()}} } }.navigationTitle("3105 ADMIN").task{await api.start()}.fileImporter(isPresented:$importing,allowedContentTypes:[UTType.data],allowsMultipleSelection:false){ result in
            switch result { case .success(let urls): guard let url=urls.first, let feature=api.features.first else { return }; Task { if let data=try? Data(contentsOf:url) { await api.uploadPackage(data,fileName:url.lastPathComponent,featureId:feature.id) } }; case .failure(let error): api.message=error.localizedDescription }
        } } }
}
