# Servidor 3105-PRO

Servidor mínimo funcional para desenvolvimento do sistema ADMIN + CLIENTE.

## Executar localmente

```bash
cd server
ADMIN_USER=admin ADMIN_PASSWORD='troque-esta-senha' ./run.sh
```

Abra `http://localhost:8787` para o painel ADMIN.

A API de cliente é `POST /api/v1/client/activate` com:

```json
{"key":"3105-...","deviceId":"identificador-do-dispositivo"}
```

A primeira ativação grava o `deviceId`. Tentativas posteriores em outro dispositivo são recusadas.

## Variáveis

- `PORT`: porta HTTP, padrão `8787`.
- `ADMIN_USER`: usuário administrativo.
- `ADMIN_PASSWORD`: senha administrativa.

O arquivo `data/db.json` é apenas para desenvolvimento. Em produção, use banco de dados, HTTPS, hash de senha administrativo e armazenamento de segredos fora do repositório.

## Cliente Swift

Os arquivos `ThreeOneOSFive/helpers/LicenseClient.swift` e `ThreeOneOSFive/views/LicenseGateView.swift` fornecem a camada de ativação. Para usar:

```swift
LicenseGateView {
    ContentView()
}
```

Antes de compilar, troque `baseURL` pelo endereço HTTPS público do servidor. O código original de patches/exploit não é alterado pela camada de licença.
