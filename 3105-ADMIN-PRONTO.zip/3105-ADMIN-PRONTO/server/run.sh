#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${ADMIN_USER:=admin}"
: "${ADMIN_PASSWORD:=change-me-now}"
ADMIN_USER="$ADMIN_USER" ADMIN_PASSWORD="$ADMIN_PASSWORD" node src/server.mjs
