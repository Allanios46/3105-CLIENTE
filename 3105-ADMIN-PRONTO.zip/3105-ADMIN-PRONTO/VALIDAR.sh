#!/usr/bin/env bash
set -euo pipefail
grep -q 'https://allanadmin-aenlcvc2.manus.space' Admin/AdminAPI.swift
grep -q 'private let adminKey = "AIOA-ADMIN-' Admin/AdminAPI.swift
test -f 3105Admin.xcodeproj/project.pbxproj
echo 'ADMIN: estrutura, nome AllanIOS e credencial técnica verificados.'
