import Foundation
import Combine

struct AdminFeature: Codable, Identifiable { let id: Int; let slug: String; var name: String; var description: String?; var enabled: Bool; let packageName: String?; let packageSize: Int? }
struct AdminClientRecord: Codable, Identifiable { let id: Int; let name: String; let email: String?; let status: String }
struct AdminKey: Codable, Identifiable { let id: Int; let label: String; let status: String; let expiresAt: String?; let client: AdminClientRecord?; let featureIds: [Int] }
struct AdminSnapshot: Codable { let keys: [AdminKey]; let features: [AdminFeature]; let clients: [AdminClientRecord] }

@MainActor final class AdminAPI: ObservableObject {
    @Published var features: [AdminFeature] = []; @Published var keys: [AdminKey] = []; @Published var message = ""; @Published var generatedKey: String?
    private var token = ""
    private let baseURL = URL(string: "https://allanadmin-aenlcvc2.manus.space")!
    // Configure esta chave uma única vez no servidor/IPA antes da distribuição.
    private let adminKey = "AIOA-ADMIN-CA7A28F8B069E04807926208"
    func start() async { do { let r: LoginResponse = try await request("/api/v1/admin/login", method: "POST", body: ["key": adminKey], authenticated: false); token = r.token ?? ""; guard !token.isEmpty else { throw APIError.message("Acesso ADMIN recusado") }; await refresh() } catch { message = error.localizedDescription } }
    func refresh() async { do { let s: AdminSnapshot = try await request("/api/v1/admin/snapshot"); features=s.features; keys=s.keys; message="Servidor HTTPS conectado." } catch { message=error.localizedDescription } }
    func createFeature(slug: String, name: String, description: String) async { do { let _: Success = try await request("/api/v1/admin/features", method:"POST", body:["slug":slug,"name":name,"description":description]); await refresh() } catch { message=error.localizedDescription } }
    func updateFeature(_ f: AdminFeature, name: String, description: String) async { do { let _: Success = try await request("/api/v1/admin/features/\(f.id)", method:"PUT", body:["name":name,"description":description]); await refresh() } catch { message=error.localizedDescription } }
    func toggle(_ f: AdminFeature, enabled: Bool) async { do { let _: Success = try await request("/api/v1/admin/features/\(f.id)", method:"PATCH", body:["enabled":enabled]); await refresh() } catch { message=error.localizedDescription } }
    func createKey(label: String, days: Int) async { do { let r: KeyCreated = try await request("/api/v1/admin/keys", method:"POST", body:["label":label,"days":days,"featureIds":features.filter{$0.enabled}.map{$0.id}]); generatedKey=r.key; await refresh() } catch { message=error.localizedDescription } }
    func uploadPackage(_ data: Data, fileName: String, featureId: Int) async {
        do { let _: Success = try await request("/api/v1/admin/features/\(featureId)/package", method:"POST", body:["fileName":fileName,"contentType":"application/octet-stream","base64":data.base64EncodedString()]); message="Pacote \(fileName) importado."; await refresh() } catch { message=error.localizedDescription }
    }
    func setKeyFeatures(_ k: AdminKey, featureIds: [Int]) async { do { let _: Success = try await request("/api/v1/admin/keys/\(k.id)/features", method:"PUT", body:["featureIds":featureIds]); await refresh() } catch { message=error.localizedDescription } }
    func deleteKey(_ k: AdminKey) async { do { let _: Success = try await request("/api/v1/admin/keys/\(k.id)", method:"DELETE"); await refresh() } catch { message=error.localizedDescription } }
    private func request<T: Decodable>(_ path: String, method: String="GET", body:[String:Any]?=nil, authenticated:Bool=true) async throws -> T { var r=URLRequest(url:baseURL.appendingPathComponent(path)); r.httpMethod=method; r.setValue("application/json",forHTTPHeaderField:"Content-Type"); if authenticated {r.setValue("Bearer \(token)",forHTTPHeaderField:"Authorization")}; if let body {r.httpBody=try JSONSerialization.data(withJSONObject:body)}; let (data,response)=try await URLSession.shared.data(for:r); guard let h=response as? HTTPURLResponse,(200..<300).contains(h.statusCode) else {throw APIError.message(String(data:data,encoding:.utf8) ?? "Falha na API")}; return try JSONDecoder().decode(T.self,from:data) }
    private struct LoginResponse: Codable { let authenticated: Bool; let token: String? }; private struct Success: Codable { let success: Bool? }; private struct KeyCreated: Codable { let key: String; let expiresAt: String? }
}
enum APIError: LocalizedError { case message(String); var errorDescription:String? { if case let .message(s)=self{return s}; return "Erro" } }
