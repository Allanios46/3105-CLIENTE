
import SwiftUI
import UniformTypeIdentifiers

struct AdminContentView: View {
    @StateObject private var api = AdminAPI()

    @State private var featureName = ""
    @State private var featureSlug = ""
    @State private var featureDesc = ""

    @State private var keyLabel = ""
    @State private var days = "30"

    @State private var fileTarget: AdminFeature?
    @State private var importing = false

    var body: some View {
        NavigationStack {
            List {
                Section("Nova função") {
                    TextField("Identificador", text: $featureSlug)
                    TextField("Nome da função", text: $featureName)
                    TextField("Descrição", text: $featureDesc)

                    Button("Criar função") {
                        Task {
                            await api.createFeature(
                                slug: featureSlug,
                                name: featureName,
                                description: featureDesc
                            )

                            featureSlug = ""
                            featureName = ""
                            featureDesc = ""
                        }
                    }
                    .disabled(featureSlug.isEmpty || featureName.isEmpty)
                }

                Section("Funções e pacotes") {
                    ForEach(api.features) { feature in
                        VStack(alignment: .leading, spacing: 10) {
                            Toggle(
                                isOn: Binding(
                                    get: { feature.enabled },
                                    set: { value in
                                        Task {
                                            await api.toggle(
                                                feature,
                                                enabled: value
                                            )
                                        }
                                    }
                                )
                            ) {
                                VStack(alignment: .leading) {
                                    Text(feature.name)
                                        .font(.headline)

                                    Text(feature.description ?? feature.slug)
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }

                            Button("Importar pacote .3105") {
                                fileTarget = feature
                                importing = true
                            }
                            .buttonStyle(.bordered)
                        }
                        .padding(.vertical, 5)
                    }
                }

                Section("Criar KEY single-device") {
                    TextField("Nome personalizado", text: $keyLabel)

                    TextField("Validade em dias", text: $days)
                        .keyboardType(.numberPad)

                    Button("Gerar KEY") {
                        Task {
                            await api.createKey(
                                label: keyLabel,
                                days: Int(days) ?? 30
                            )
                        }
                    }

                    if let key = api.generatedKey {
                        Text("KEY gerada: \(key)")
                            .textSelection(.enabled)
                            .foregroundStyle(.green)
                    }
                }

                Section("KEYs e clientes") {
                    ForEach(api.keys) { key in
                        VStack(alignment: .leading, spacing: 8) {
                            Text(key.label)
                                .bold()

                            Text("\(key.status) • Expira: \(key.expiresAt ?? "-")")
                                .font(.caption)

                            Text("Cliente: \(key.client?.name ?? "Livre")")
                                .font(.caption)

                            HStack {
                                Button("Excluir", role: .destructive) {
                                    Task {
                                        await api.deleteKey(key)
                                    }
                                }

                                Button("Permissões") {
                                    Task {
                                        await api.setKeyFeatures(
                                            key,
                                            featureIds: api.features
                                                .filter { $0.enabled }
                                                .map { $0.id }
                                        )
                                    }
                                }
                            }
                        }
                        .padding(.vertical, 5)
                    }
                }

                Section("Status") {
                    Text(api.message)
                        .font(.footnote)

                    Button("Atualizar agora") {
                        Task {
                            await api.refresh()
                        }
                    }
                }
            }
            .navigationTitle("3105 ADMIN")
            .task {
                await api.start()
            }
            .fileImporter(
                isPresented: $importing,
                allowedContentTypes: [.data],
                allowsMultipleSelection: false
            ) { result in
                switch result {
                case .success(let urls):
                    guard
                        let url = urls.first,
                        let feature = fileTarget
                    else {
                        return
                    }

                    guard url.pathExtension.lowercased() == "3105" else {
                        api.message = "Selecione um arquivo com extensão .3105"
                        return
                    }

                    Task {
                        let access = url.startAccessingSecurityScopedResource()
                        defer {
                            if access {
                                url.stopAccessingSecurityScopedResource()
                            }
                        }

                        do {
                            let data = try Data(contentsOf: url)

                            await api.uploadPackage(
                                featureID: feature.id,
                                filename: url.lastPathComponent,
                                data: data
                            )

                        } catch {
                            api.message = error.localizedDescription
                        }
                    }

                case .failure(let error):
                    api.message = error.localizedDescription
                }

                fileTarget = nil
            }
        }
    }
}
