import SwiftUI

@main
struct AllanIOSExternalAdminApp: App {
    var body: some Scene { WindowGroup { AdminContentView() } }
}
