# 3105 ADMIN

Projeto Xcode independente para gerar a segunda IPA: Allan IOS EXTERNAL ADMIN.

Abra `3105Admin.xcodeproj`, configure a URL HTTPS em `Admin/AdminAPI.swift`, escolha o esquema `3105 ADMIN` e arquive. O servidor está em `server/`.
