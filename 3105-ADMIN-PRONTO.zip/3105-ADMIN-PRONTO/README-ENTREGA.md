# IPA ADMIN — AllanIOS

Painel administrativo separado, baseado no projeto original 3105 e sem tela de login visual. Ao abrir, o app tenta autenticar automaticamente na API HTTPS central e mostra o painel.

Permite criar funções, ativar/desativar funções globais, criar KEYs com validade, consultar KEYs/clientes, atualizar permissões e excluir KEYs. A importação de pacote `.3105` usa o endpoint de pacote da API e deve ser ligada à tela de seleção de arquivo na próxima revisão visual.

- API: `https://allanadmin-aenlcvc2.manus.space`
- Projeto Xcode: `3105Admin.xcodeproj`
- Scheme: `3105 ADMIN`
- Runner GitHub Actions: `macos-14`

## Configuração obrigatória da KEY ADMIN

Abra `Admin/AdminAPI.swift` e substitua:

`credencial configurada no projeto`

pela credencial já configurada no arquivo `Admin/AdminAPI.swift`. Ela não deve ser enviada aos clientes nem publicada em repositório público. A ausência de tela não significa ausência de autenticação técnica: o servidor continua validando o Bearer token.
