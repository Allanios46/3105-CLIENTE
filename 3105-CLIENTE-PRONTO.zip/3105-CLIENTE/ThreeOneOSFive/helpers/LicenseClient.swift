import Foundation
import Combine
import UIKit

struct LicenseFeature: Codable, Identifiable {
    let id: String
    let name: String
    let description: String
}

struct LicenseResponse: Codable {
    let valid: Bool
    let keyId: String?
    let name: String?
    let expiresAt: String?
    let features: [LicenseFeature]?
    let error: String?
}

@MainActor
final class LicenseClient: ObservableObject {
    @Published private(set) var license: LicenseResponse?
    @Published private(set) var isLoading = false
    @Published var message = ""

    private let baseURL: URL
    private let keyStore = "3105.pro.license.key"
    private let deviceStore = "3105.pro.device.id"

    init(baseURL: URL = URL(string: "https://allanadmin-aenlcvc2.manus.space")!) {
        self.baseURL = baseURL
    }

    var deviceID: String {
        if let saved = UserDefaults.standard.string(forKey: deviceStore) { return saved }
        let value = UIDevice.current.identifierForVendor?.uuidString ?? UUID().uuidString
        UserDefaults.standard.set(value, forKey: deviceStore)
        return value
    }

    var savedKey: String? { UserDefaults.standard.string(forKey: keyStore) }
    var enabledFeatureIDs: Set<String> { Set(license?.features?.map(\.id) ?? []) }

    func activate(key: String) async {
        let normalized = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !normalized.isEmpty else { message = "Digite uma KEY."; return }
        isLoading = true; defer { isLoading = false }
        do {
            var request = URLRequest(url: baseURL.appendingPathComponent("/api/v1/client/activate"))
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = try JSONEncoder().encode(["key": normalized, "deviceId": deviceID])
            let (data, response) = try await URLSession.shared.data(for: request)
            let result = try JSONDecoder().decode(LicenseResponse.self, from: data)
            guard (response as? HTTPURLResponse)?.statusCode == 200, result.valid else {
                message = result.error ?? "KEY recusada pelo servidor"; return
            }
            license = result; UserDefaults.standard.set(normalized, forKey: keyStore); message = "KEY ativada."
        } catch { message = "Não foi possível consultar o servidor: \(error.localizedDescription)" }
    }

    func deactivate() {
        license = nil; UserDefaults.standard.removeObject(forKey: keyStore); message = "KEY removida deste aplicativo."
    }
}
