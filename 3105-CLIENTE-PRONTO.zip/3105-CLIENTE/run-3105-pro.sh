#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SERVER_DIR="$ROOT_DIR/server"

if ! command -v node >/dev/null 2>&1; then
  echo "Erro: Node.js não encontrado. Instale Node.js 20 ou superior."
  exit 1
fi

export PORT="${PORT:-8787}"
export ADMIN_USER="${ADMIN_USER:-admin}"
export ADMIN_PASSWORD="${ADMIN_PASSWORD:-change-me-now}"

if [[ "$ADMIN_PASSWORD" == "change-me-now" ]]; then
  echo "AVISO: usando senha padrão de desenvolvimento."
  echo "Para uso real, execute com:"
  echo "ADMIN_PASSWORD='uma-senha-forte' $0"
fi

if [[ ! -f "$SERVER_DIR/src/server.mjs" ]]; then
  echo "Erro: servidor não encontrado em $SERVER_DIR/src/server.mjs"
  exit 1
fi

cd "$SERVER_DIR"
echo "Allan IOS EXTERNAL — 3105-PRO"
echo "Servidor: http://127.0.0.1:$PORT"
echo "Painel ADMIN: http://127.0.0.1:$PORT"
echo "Usuário ADMIN: $ADMIN_USER"
echo "Pressione Ctrl+C para encerrar."

exec node src/server.mjs
