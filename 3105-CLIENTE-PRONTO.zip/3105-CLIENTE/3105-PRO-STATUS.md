# 3105-PRO CLIENTE

Projeto independente da IPA CLIENTE Allan IOS EXTERNAL.

Abra `3105Client.xcodeproj` e selecione o esquema `3105`. Configure a URL HTTPS do servidor em `ThreeOneOSFive/helpers/LicenseClient.swift` e `ThreeOneOSFive/views/LicenseGateView.swift`.
