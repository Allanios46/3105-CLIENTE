# IPA CLIENTE — EXTERNAL Allan iOS

Projeto baseado no código original 3105. O aplicativo usa a API HTTPS central para ativação por KEY single-device e recebe as funções liberadas pelo servidor.

- Nome exibido: `EXTERNAL Allan iOS`
- API: `https://allanadmin-aenlcvc2.manus.space`
- Projeto Xcode: `3105Client.xcodeproj`
- Scheme: `3105`
- Runner GitHub Actions: `macos-14`

A compilação real precisa ser executada em macOS/Xcode pelo GitHub Actions. Instalação real no iPhone ainda exige assinatura Apple e provisioning profile.
