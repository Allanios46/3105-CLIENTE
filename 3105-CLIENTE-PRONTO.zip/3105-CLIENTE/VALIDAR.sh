#!/usr/bin/env bash
set -euo pipefail
grep -q 'EXTERNAL Allan iOS' ThreeOneOSFive/Info.plist
grep -q 'https://allanadmin-aenlcvc2.manus.space' ThreeOneOSFive/helpers/LicenseClient.swift
test -f 3105Client.xcodeproj/project.pbxproj
echo 'CLIENTE: estrutura e identidade verificadas.'
