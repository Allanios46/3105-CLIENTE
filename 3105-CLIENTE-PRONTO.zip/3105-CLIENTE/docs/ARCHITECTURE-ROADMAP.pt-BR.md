# Roteiro de arquitetura do 3105-PRO

## Componentes

### Cliente

Uma única aplicação iOS para todos os clientes. Deve possuir tela de ativação de KEY, registro de dispositivo, consulta de permissões e lista de funções liberadas. A aplicação deve manter uma cópia segura do estado anterior para permitir restauração quando uma função for desativada.

### Admin

Aplicação separada para autenticação administrativa, cadastro de funções, cadastro de patches, criação de KEYs, validade, bloqueio/desbloqueio, clientes, dispositivos e permissões.

### Servidor

API central responsável por autenticar o ADMIN, validar KEYs, vincular uma KEY a um único dispositivo, devolver permissões e registrar revogações. A decisão de validade deve ser feita no servidor; o cliente não deve confiar apenas no relógio local.

## Modelo mínimo de dados

- `keys`: valor hash da KEY, nome, estado, validade, cliente e dispositivo vinculado.
- `features`: nome, descrição, estado e versão.
- `key_features`: relação entre KEYs e funções.
- `devices`: identificador público do dispositivo, modelo, primeiro acesso e último acesso.
- `audit_log`: ações administrativas e alterações de vínculo/permissão.

## Regras definidas

- Distribuição individual.
- Uma KEY para um único dispositivo.
- Validade personalizada.
- Uma IPA CLIENTE compartilhada por todos os clientes.
- Funções exibidas somente quando liberadas pelo servidor.
- Bloqueio no servidor invalida novos usos e renovações.

## Pendências técnicas

Antes da implementação final, definir domínio da API, hospedagem, banco, autenticação do ADMIN, política de rotação de segredos, formato dos patches e estratégia de versionamento. Nenhum segredo de produção deve ser colocado no repositório ou dentro da IPA.
